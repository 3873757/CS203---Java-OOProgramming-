import java.util.Scanner;
public class Player {
	private int luckynumber;

	public int getLuckynumber() {
		return luckynumber;
	}

	public void setLuckynumber(int luckynumber) {
		this.luckynumber = luckynumber;
	}

	public void guess() {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter ur luckynumber");

		int luckynumber1 = in.nextInt();
		setLuckynumber(luckynumber1);
	}

}
