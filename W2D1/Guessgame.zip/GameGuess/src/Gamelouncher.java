import java.util.*;
class Guessgame
{
	Player p1;
	Player p2;
	Player p3;
	public void startGame()
	{
		p1 = new Player();
		p2 = new Player();
		p3 = new Player();	
		boolean p1isRight = false;
		boolean p2isRight =  false;
		boolean p3isRight = false;
		int targetNumber =  (int)(Math.random()*10);;
		while(true){			
			p1.guess();
			p2.guess();
			p3.guess();
			System.out.println("player1 Guess " +p1.getLuckynumber());
			System.out.println("player2 Guess " +p2.getLuckynumber());
			System.out.println("player3 Guess " +p3.getLuckynumber());
			System.out.println("number to guss is :"+ targetNumber);			
			if(p1.getLuckynumber()== targetNumber)
			{
				p1isRight = true;
			}
			if(p2.getLuckynumber()== targetNumber)
			{
				p2isRight = true;
			}
			if(p3.getLuckynumber()== targetNumber)
			{
				p3isRight = true;
			}
			if(p1isRight||p2isRight||p3isRight)
			if(p1isRight)
			{
				System.out.println("we have a winner");
				System.out.println("player1 got it right?" +p1isRight);
				System.out.println("player2 got it right?" +p2isRight);
				System.out.println("player3 got it right?" +p3isRight);
				System.out.println("Game is Over");
				break;
			}
			else 
			{
				System.out.println("players will have try again");	
			}
		}
	}
}
                                 //main class ***Tester ****************
public class Gamelouncher 
{
	public static void main(String[] args) 
	{
		Guessgame game = new Guessgame();
		game.startGame();
	}
}
